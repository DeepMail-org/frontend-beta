# Design System Specification: The Neon Nocturne

## 1. Overview & Creative North Star
**Creative North Star: The Sentinel’s Veil**
This design system rejects the "SaaS-standard" dashboard in favor of a high-fidelity, cinematic command center. It is inspired by the aesthetics of cyber-noir—where deep shadows meet piercing, neon data points. By leveraging intentional asymmetry, overlapping frosted surfaces, and high-contrast typography, we move away from a flat "web app" feel toward an immersive, tactical environment.

**The Editorial Shift:**
We break the rigid grid by treating data as a narrative. We use "Space Grotesk" not just for readability, but as a structural element. Layouts should feel like a heads-up display (HUD), utilizing breathing room (`spacing-12` and `spacing-16`) to let critical security alerts "shout" while secondary telemetry "whispers" in the background.

---

## 2. Colors & Surface Logic
The palette is rooted in the "Dracula" heritage—deep, cold neutrals juxtaposed with electric, "glowing" functional accents.

### Color Roles
- **Background (`#11131e`):** The void. All interfaces start here.
- **Primary (`#d7baff`):** Radiant Purple. Used for the most critical user actions.
- **Secondary (`#ffafd7`):** Electric Pink. Used for high-priority alerts and active states.
- **Tertiary (`#31e368`):** Glowing Green. Used for "System Healthy" or "Secure" status.
- **Error (`#ffb4ab`):** Vibrant Orange/Red. Reserved strictly for active breaches or system failures.

### The "No-Line" Rule
**Explicit Instruction:** Do not use 1px solid borders to define sections.
Boundaries are created through **Tonal Shifts**. To separate a sidebar from a main feed, use `surface-container-low` against the `background`. To define a card, use `surface-container-high` against `surface-container-low`. 

### The Glass & Gradient Rule
To achieve a premium "Cybersecurity" feel, main CTAs and header elements must use linear gradients:
- **Primary Action:** Transition from `primary` (#d7baff) to `primary-container` (#bd93f9).
- **Glassmorphism:** For floating modals or navigation overlays, use `surface-variant` at 60% opacity with a `24px` backdrop-blur. This allows the "glow" of data visualizations underneath to bleed through.

---

## 3. Typography
**Space Grotesk** is our structural backbone. It bridges the gap between technical monospaced fonts and high-end editorial sans-serifs.

- **Display (lg/md/sm):** Used for "Big Numbers" (e.g., Total Threats Blocked). Set with `-0.02em` letter spacing to feel compact and aggressive.
- **Headline (lg/md):** Used for page titles. Always in `on-surface` color.
- **Title (md/sm):** Used for card headings. Use `primary` or `secondary` tokens here to draw the eye to specific data modules.
- **Body (lg/md):** All technical readouts. Use `on-surface-variant` (#ccc3d3) for secondary descriptions to maintain a clear hierarchy.
- **Label (md/sm):** All-caps for metadata, timestamping, or "System Status" tags.

---

## 4. Elevation & Depth
In this system, depth is not simulated with heavy shadows, but with **Tonal Layering** and light.

### The Layering Principle
1. **Base Layer:** `surface` (#11131e).
2. **Sub-Section:** `surface-container-low` (#191b26).
3. **Interactive Card:** `surface-container-high` (#272935).
4. **Active/Hover State:** `surface-container-highest` (#323440).

### Ambient Shadows & Neon Glow
When an element must "float" (e.g., a critical alert popover), use an **Ambient Glow** instead of a shadow:
- **Shadow Property:** `0px 20px 40px rgba(189, 147, 249, 0.15)`. (A subtle purple tint that mimics the light cast by a neon screen).

### The "Ghost Border" Fallback
If contrast is required (e.g., in a complex data table), use a **Ghost Border**: `outline-variant` (#4a4451) at 15% opacity. Never 100%.

---

## 5. Components

### Buttons
- **Primary:** Gradient fill (`primary` to `primary_container`), `on-primary` text. `rounded-md`. Apply a subtle outer glow on hover.
- **Secondary:** Transparent background with a `Ghost Border`. Text in `secondary`.
- **Tertiary:** No background, no border. `on-surface` text with an underline on hover.

### Inputs & Search
- **Visuals:** Use `surface-container-lowest` for the field background. No border. On focus, add a 1px `primary` border and a soft `primary` outer glow.
- **Labels:** Always use `label-md` floating above the field in `on-surface-variant`.

### Cards & Lists
- **Rule:** Forbid divider lines. 
- **Execution:** Use `spacing-4` (1rem) between list items. Use a slight background shift (`surface-container-high`) for the even rows in a table to create a "Zebra" effect without lines.

### Cybersecurity-Specific: The "Status Glow"
- **Threat Levels:** Use `tertiary` (Green) for safe, `orange` for warning, and `secondary` (Pink) for critical. These should not be flat circles; they should be 8px dots with a 12px blur radius of the same color to simulate a glowing LED on hardware.

---

## 6. Do’s and Don’ts

### Do:
- **Do** use `spacing-10` and `spacing-12` to separate major functional areas. Wide margins equate to "Premium" design.
- **Do** use high-contrast typography (e.g., a `Display-lg` metric next to a `Label-sm` unit).
- **Do** use `backdrop-blur` (12px–32px) on all floating navigation or modal components.

### Don’t:
- **Don’t** use pure black (#000) or pure white (#fff). Always use the provided tokens to maintain the "Dracula" tonal depth.
- **Don’t** use 100% opaque borders. It breaks the "futuristic" HUD illusion.
- **Don’t** clutter. If a screen feels full, increase the `spacing` tokens and move secondary data into a `surface-container-low` drawer.

---

## 7. Spacing & Radius
- **Radius:** Standardize on `md` (0.375rem) for UI controls (buttons, inputs) and `xl` (0.75rem) for containers (cards, dashboards).
- **Spacing:** Use the 4px-base scale. Use `spacing-2` for internal element padding and `spacing-8` for external component margins.