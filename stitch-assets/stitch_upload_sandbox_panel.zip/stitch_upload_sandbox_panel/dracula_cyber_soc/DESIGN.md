# Design System Strategy: The Cyber-Gothic Interface

## 1. Overview & Creative North Star
**Creative North Star: "The Neon Nocturne"**

This design system rejects the "flat and sterile" trend of modern SaaS. Instead, it embraces a high-end editorial approach to cybersecurity monitoring. By blending the high-contrast readability of a professional SOC (Security Operations Center) with the moody, layered depth of a "Cyber-Gothic" aesthetic, we create an environment that feels both authoritative and immersive.

The system breaks the standard "box-within-a-box" layout by utilizing **intentional asymmetry** and **tonal layering**. Elements are not merely placed on a grid; they are submerged into a deep, near-black ether, illuminated only by the vibrant energy of the Dracula-inspired accents. The goal is to make the analyst feel like they are interacting with a living data organism, not just a dashboard.

---

## 2. Colors & Surface Philosophy
The palette is built on the foundation of the `surface` tokens. We do not use "white" or "pure black" for UI elements; we use varying densities of light and shadow.

### The "No-Line" Rule
**Explicit Instruction:** 1px solid borders for sectioning are strictly prohibited. 
Structural boundaries must be defined through background color shifts or subtle tonal transitions. For example, a sidebar should be `surface_container_low` sitting against a `background` viewport. The human eye will perceive the edge through the shift in luminance, creating a cleaner, more sophisticated interface.

### Surface Hierarchy & Nesting
Treat the UI as a series of physical layers—like stacked sheets of tinted, frosted glass.
- **Base Layer:** `surface` (#0a0e19)
- **Primary Workspaces:** `surface_container` (#141927)
- **Interactive Widgets:** `surface_container_high` (#1a1f2e)
- **Floating Overlays:** `surface_bright` (#262c3d)

### The "Glass & Gradient" Rule
To elevate the experience, use **Glassmorphism** for floating elements. Apply `surface_variant` with a 60% opacity and a `backdrop-blur` of 12px–20px. 
**Signature Textures:** For primary actions (CTAs), use a subtle linear gradient (135°) transitioning from `primary` (#c49aff) to `primary_container` (#b68df2). This provides a "soul" to the component that flat hex codes cannot replicate.

---

## 3. Typography: Editorial Authority
We utilize a dual-font system to balance technical precision with modern elegance.

*   **Display & Headlines (Space Grotesk):** Used for data points, page titles, and high-impact headers. The geometric nature of Space Grotesk provides a "monospaced-adjacent" feel that suggests technical accuracy.
*   **Body & Titles (Inter):** Used for long-form content, logs, and UI labels. Inter’s tall x-height ensures maximum readability against dark backgrounds.

**Hierarchy of Intent:**
- **Display-LG (3.5rem):** Reserved for critical metrics (e.g., "99.9% Uptime").
- **Headline-SM (1.5rem):** Used for widget titles to establish a clear hierarchy.
- **Label-SM (0.6875rem):** Used for metadata and timestamps, always in `on_surface_variant` to reduce visual noise.

---

## 4. Elevation & Depth
Depth is achieved through **Tonal Layering** rather than traditional drop shadows.

*   **The Layering Principle:** Place a `surface_container_lowest` card on a `surface_container_low` section. The slight "dip" in brightness creates a natural indentation that guides the eye without needing a border.
*   **Ambient Shadows:** When an element must "float" (like a dropdown), use an extra-diffused shadow: `box-shadow: 0 12px 40px rgba(0, 0, 0, 0.5)`. The shadow should be tinted with the `background` color to ensure it feels like part of the environment.
*   **The "Ghost Border" Fallback:** If accessibility requires a border, use the `outline_variant` token at **15% opacity**. Never use 100% opaque borders.
*   **Glow Effects:** Critical alerts (`error`) or primary states (`primary`) should have a subtle outer glow using their respective color at 10% opacity to simulate a CRT-style light bleed.

---

## 5. Components

### Buttons
- **Primary:** Gradient fill (`primary` to `primary_container`), `on_primary` text. No border. Soft `sm` corner radius.
- **Secondary:** Transparent background, `ghost border` (outline_variant @ 20%), `primary` text color.
- **States:** On hover, increase the gradient luminosity. On active, scale the button to 0.98 for tactile feedback.

### Input Fields
- **Styling:** Use `surface_container_highest` for the field background. 
- **States:** No border on idle. On focus, a 1px `primary` border is permitted, accompanied by a 4px soft glow of the same color.

### Data Widgets & Charts
- **Forbid Dividers:** Use vertical white space (Spacing `8` or `10`) to separate chart segments. 
- **Success/Safe:** `tertiary` (#b8ffbb).
- **Warning:** `secondary` (#fd77c4) — the electric pink acts as a non-standard, high-attention warning.
- **Critical:** `error` (#ff6e84).

### Cyber-SOC Specialized Components
- **Pulse Indicators:** A small dot using `tertiary` with a repeating scale-and-fade animation to show "Live" connectivity.
- **Glass-Cards:** Use for analytical widgets. Background: `surface_container` at 70% opacity + 15px backdrop-blur.

---

## 6. Do's and Don'ts

### Do
- **Do** use `surface_container` tiers to create hierarchy.
- **Do** allow content to breathe. Use the Spacing Scale (`12` and `16`) for margin between major modules.
- **Do** use `Space Grotesk` for numbers—it is designed for technical legibility.

### Don't
- **Don't** use `#000000` (pure black) for anything other than the deepest "void" backgrounds (`surface_container_lowest`).
- **Don't** use standard "Grey" for text. Use `on_surface_variant` (#a7aaba) which is slightly tinted toward the navy base.
- **Don't** use 1px solid white lines. They "vibrate" against the dark background and cause eye strain.
- **Don't** use sharp corners. Stick to the `md` (0.375rem) or `lg` (0.5rem) roundedness scale to keep the "Glass" aesthetic feeling premium.