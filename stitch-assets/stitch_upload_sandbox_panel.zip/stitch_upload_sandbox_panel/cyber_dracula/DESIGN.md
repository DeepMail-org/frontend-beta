# Design System Strategy: The Neon Nocturne

## 1. Overview & Creative North Star
**Creative North Star: The Synthetic Sentinel**

This design system is not merely a "dark mode" interface; it is a high-fidelity digital cockpit designed for the elite cybersecurity operator. It rejects the flat, corporate "SaaS-blue" aesthetic in favor of **Synthetic Nocturne**—a visual language defined by extreme contrast, deep atmospheric layering, and bioluminescent accents.

To break the "template" look, we employ **Intentional Asymmetry**. Instead of rigid, centered grids, we use weighted layouts where data visualizations "glow" out of the darkness. We utilize overlapping glass surfaces and "leaking" neon light to create a sense of three-dimensional depth, making the interface feel like a physical head-up display (HUD) rather than a flat webpage.

---

## 2. Colors: Chromatic Depth & The "No-Line" Rule
The palette is rooted in the "Dracula" heritage but elevated for a premium, editorial feel.

### The Palette
*   **Primary (Vivid Purple):** `#c49aff` — Used for "Action Energy." It is the heartbeat of the system.
*   **Secondary (Electric Pink):** `#fd77c4` — Used for "System Intelligence" and secondary highlights.
*   **Tertiary (Glowing Green):** `#b8ffbb` — Reserved strictly for "Secure/Safe" states.
*   **Background (Deep Navy):** `#0a0e19` — The infinite void.

### The "No-Line" Rule
**Explicit Instruction:** Do not use 1px solid borders to define sections. Traditional boxes feel "heavy" and "standard." 
*   **Defining Boundaries:** Use background shifts. A `surface-container-low` section sitting on a `surface` background is enough to define a zone. 
*   **The "Glass & Gradient" Rule:** For high-level containers, use backdrop-blur (12px–20px) with a `surface-variant` at 40% opacity. 
*   **Signature Textures:** Main CTAs should not be flat. Use a subtle linear gradient from `primary` to `primary-container` at a 135-degree angle to give the element "mass" and a metallic, neon sheen.

---

## 3. Typography: The Futuristic Editorial
We use **Space Grotesk** across the entire system. Its monospaced-adjacent quirks provide a "hacker-chic" precision while remaining highly legible.

*   **Display (Lg/Md):** 3.5rem / 2.75rem. Use `display-lg` for high-impact data points (e.g., "99+ Threats Blocked"). Set with tight letter-spacing (-0.02em) to feel authoritative.
*   **Headline (Lg/Md):** 2rem / 1.75rem. These are the anchors. Use `headline-sm` for card titles to ensure the UI feels editorial rather than purely functional.
*   **Body (Lg/Md):** 1rem / 0.875rem. Always use `on-surface-variant` (`#a7aaba`) for long-form text to reduce eye strain against the near-black background.
*   **Label (Md/Sm):** 0.75rem / 0.6875rem. Use for technical metadata. These should often be in ALL CAPS with +0.05em tracking to mimic a terminal readout.

---

## 4. Elevation & Depth: Tonal Layering
In this system, "Elevation" is not a shadow; it is a **light-source**.

### The Layering Principle
Depth is achieved by "stacking" the surface-container tiers. 
*   **Level 0 (Background):** `surface-dim` (`#0a0e19`).
*   **Level 1 (Sections):** `surface-container-low` (`#0f131f`).
*   **Level 2 (Cards):** `surface-container` (`#141927`).
*   **Level 3 (Pop-overs):** `surface-bright` (`#262c3d`).

### Ambient Glows & Ghost Borders
*   **Ambient Shadows:** For floating elements, use a shadow with a 40px blur, 0% spread, and 8% opacity. The shadow color should be `primary` (`#c49aff`), not black, to simulate the neon light hitting the background.
*   **The Ghost Border:** If a container requires a border for accessibility, use `outline-variant` at **15% opacity**. It should feel like a "whisper" of a line.
*   **Glassmorphism:** Apply `backdrop-filter: blur(12px)` to any element with a `surface-variant` background. This pulls the background colors through the container, creating a "frosted glass" effect that feels integrated into the environment.

---

## 5. Components: Style Guide

### Buttons
*   **Primary:** Gradient fill (`primary` to `primary-container`), no border, `on-primary` text. Add a subtle `0 0 15px` outer glow on hover using the `primary` color.
*   **Secondary:** Ghost style. `outline` border at 30% opacity, `primary` text.
*   **Tertiary:** No background. `secondary` (`#fd77c4`) text with an underline that only appears on hover.

### Cards & Lists
*   **Forbid Dividers:** Do not use horizontal lines between list items. Use **1.5rem (24px)** of vertical white space to separate items.
*   **Nesting:** Place `surface-container-highest` chips inside a `surface-container` card to create a "recessed" look.

### Input Fields
*   **State:** The default state is a `surface-container-lowest` background (pure black) with a `Ghost Border`.
*   **Focus State:** The border transitions to 100% `primary` opacity, and a 2px "inner glow" of the `primary` color is applied to make the field feel "electrified."

### Cyber-Specific Components
*   **Threat Meter:** A semi-circle gauge using a gradient from `tertiary` (Safe) to `error` (Danger).
*   **Terminal Output:** A `surface-container-lowest` block with `body-sm` text in `tertiary_fixed_dim`. No scrollbars; use a subtle fade-to-black at the bottom.

---

## 6. Do’s and Don’ts

### Do:
*   **Do** use intentional asymmetry. Align a headline to the left and a data-viz to the far right, leaving "dead space" in the middle to emphasize the void.
*   **Do** use `secondary_fixed` (`#ffc0de`) for small accents like notification dots or active status indicators.
*   **Do** ensure all "Glass" components have a `backdrop-filter`—without it, the UI looks muddy.

### Don’t:
*   **Don’t** use pure white text. Use `on-surface` (`#e8eafb`) to maintain the "Dracula" tonal balance.
*   **Don’t** use rounded corners larger than `xl` (0.75rem) for main containers. Cybersecurity requires a degree of "sharpness"; too much roundness feels too consumer-soft.
*   **Don’t** use "Drop Shadows" that are black. If it’s floating, it must cast a colored, ambient glow.