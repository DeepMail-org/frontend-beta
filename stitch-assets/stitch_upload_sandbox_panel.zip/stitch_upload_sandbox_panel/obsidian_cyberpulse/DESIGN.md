# Design System Strategy: The Nocturnal Intelligence Framework

## 1. Overview & Creative North Star
**Creative North Star: "The Ethereal Sentinel"**
This design system moves away from the "cluttered cockpit" trope of cybersecurity tools and instead adopts an editorial, high-end aesthetic. It treats data not as noise, but as a curated gallery of intelligence. We break the traditional "boxed-in" dashboard template by utilizing **intentional asymmetry** and **atmospheric depth**. 

By leveraging a hierarchy of translucency and "glowing" focal points, we ensure that SOC analysts can maintain focus during long shifts without cognitive fatigue. The UI should feel like a high-end physical console made of layered obsidian and frosted glass—authoritative, silent, and precise.

## 2. Colors & Surface Philosophy
The palette is rooted in the deep void of the `surface` color, using light and translucency to define space rather than lines.

### The "No-Line" Rule
**Explicit Instruction:** Do not use 1px solid borders to section off parts of the UI. Separation must be achieved through:
1.  **Background Shifts:** Placing a `surface_container_low` element against the `surface` background.
2.  **Tonal Transitions:** Using the subtle difference between `surface_container` and `surface_container_high`.
3.  **Negative Space:** Utilizing the `spacing-8` (1.75rem) or `spacing-10` (2.25rem) tokens to create "breathing rooms" that act as invisible boundaries.

### Surface Hierarchy & Nesting
Treat the interface as a physical stack of materials:
*   **Base Layer:** `surface` (#0a0e19) – The infinite background.
*   **Sub-Sectioning:** `surface_container_low` – Used for large logical groupings (e.g., the sidebar area).
*   **Active Workspaces:** `surface_container` – The primary "desk" surface.
*   **Actionable Cards:** `surface_container_high` – Elevated focus areas.

### The "Glass & Gradient" Rule
To achieve the "Futuristic" requirement, use `surface_tint` at 10% opacity combined with a `backdrop-blur` (12px-20px) for floating modals or popovers. 
*   **Signature Textures:** Apply a linear gradient from `primary` to `secondary` at a 135-degree angle for high-priority CTAs or "Threat Level" indicators. This creates a visual "soul" that differentiates the system from flat, utility-only tools.

---

## 3. Typography: The Editorial Edge
We pair the geometric precision of **Space Grotesk** for data-heavy headers with the hyper-legibility of **Inter** for analytical reading.

*   **Display (Space Grotesk):** Use `display-lg` and `display-md` sparingly for high-level metrics (e.g., "99.9% Secure"). The exaggerated character widths convey a high-tech, premium feel.
*   **Headlines & Titles:** `headline-sm` and `title-lg` provide clear anchors for SOC sections without needing heavy dividers.
*   **Body (Inter):** All analytical text must use `body-md`. For tabular data or log files, use a monospace font at `label-sm` sizing to ensure character alignment.
*   **Hierarchy through Contrast:** Use `on_surface_variant` (a muted slate) for secondary labels and metadata, reserving `on_surface` (bright white-blue) strictly for primary data points and active text.

---

## 4. Elevation & Depth: Tonal Layering
In this system, "Elevation" is a measure of light, not just shadow.

*   **The Layering Principle:** Place a `surface_container_highest` card inside a `surface_container_low` section to create "Natural Lift."
*   **Ambient Shadows:** For floating elements (Modals, Tooltips), use an extra-diffused shadow: `box-shadow: 0 20px 40px rgba(0, 0, 0, 0.4)`. The shadow should feel like a soft atmospheric occlusion, not a hard drop-shadow.
*   **The "Ghost Border" Fallback:** If a container sits on a background of the same color, use a "Ghost Border": `outline-variant` at 15% opacity. This provides a tactile edge without introducing "grid-clutter."
*   **Glow States:** Interaction triggers (Hover/Active) should use a subtle outer glow using the `primary_dim` color at 20% opacity to simulate a light-emissive screen.

---

## 5. Components

### Buttons
*   **Primary:** A gradient from `primary` to `primary_dim`. Roundedness: `md`. No border.
*   **Secondary:** `surface_container_highest` background with a `Ghost Border` of `outline_variant`.
*   **Tertiary:** Transparent background, `primary` text. Use only for low-emphasis actions like "Cancel" or "View Less."

### Glassmorphism Cards
*   **Background:** `surface_variant` at 60% opacity.
*   **Blur:** 16px backdrop-filter.
*   **Edge:** Top and left edges should have a 1px "highlight" (Primary at 20% opacity) to simulate light catching the glass edge.

### Data Grids & Lists
*   **Zero Dividers:** Forbid the use of horizontal lines. Distinguish rows through alternating `surface_container` and `surface_container_low` backgrounds (zebra striping) or simply through 12px of vertical padding (`spacing-4`).
*   **Status Indicators:** Use `tertiary` (Safe), `error` (Danger), and `secondary` (Warning). These should be small, glowing pips rather than large blocks of color.

### Monospace Code Blocks (Log Viewer)
*   **Background:** `surface_container_lowest` (#000000).
*   **Padding:** `spacing-5`.
*   **Border-radius:** `sm`.
*   **Text:** `on_surface_variant` for keys, `primary` for values.

---

## 6. Do’s and Don’ts

### Do:
*   **Use High-Contrast Scales:** Jump from `display-lg` to `label-md` to create visual interest.
*   **Embrace Asymmetry:** Let the sidebar be significantly darker than the main stage to "push" the content forward.
*   **Use Micro-Interactions:** Apply a 200ms ease-out transition to all hover states involving `surface_tint`.

### Don’t:
*   **Don't use 100% Opaque Borders:** This kills the "Glassmorphism" effect and makes the dashboard feel like a legacy spreadsheet.
*   **Don't Over-Glow:** Glows should be reserved for critical alerts (`error`) or primary actions. If everything glows, nothing is important.
*   **Don't Use Pure Grey:** Our neutrals are slates and navies. Avoid `#333333` or `#cccccc`. Always lean into the `outline` and `outline_variant` tokens which carry the blue-tinted DNA of the system.