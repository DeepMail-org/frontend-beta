# Design System Specification: The Neon Sentinel

## 1. Overview & Creative North Star
**Creative North Star: "The Synthetic Command"**

In the high-stakes world of cybersecurity, "standard" dashboards feel like spreadsheets. This design system rejects the clinical, flat aesthetic of enterprise software in favor of a high-fidelity, cinematic "Command Center" experience. It draws inspiration from 1980s retro-futurism and modern tactical interfaces—mixing the aggressive high-contrast of the Dracula palette with the sophisticated depth of glassmorphism.

The system breaks the "template" look by utilizing **intentional asymmetry**. Layouts should prioritize information density in core "nodes" while allowing negative space to flow around them. We don't just display data; we stage it. Elements should feel like they are floating in a vacuum, illuminated by the internal glow of the data itself.

---

## 2. Colors & Surface Logic

### The "No-Line" Rule
Standard 1px borders are strictly prohibited for layout sectioning. In this system, boundaries are defined by **luminance shifts**. Use the `surface-container` tiers to create separation. A module should sit on the `background` (#0f131e) by utilizing a `surface-container-low` (#171b27) fill. 

### Surface Hierarchy & Nesting
Treat the UI as a series of stacked, semi-translucent plates.
- **Layer 0 (Base):** `background` (#0f131e) — The void.
- **Layer 1 (Main Panels):** `surface-container-low` (#171b27) — Softly defined zones.
- **Layer 2 (Interactive Modules):** `surface-container-high` (#262a36) — Active widgets.
- **Layer 3 (Floating Overlays):** `surface-bright` (#353945) — Tooltips and Modals.

### The Glass & Gradient Rule
To achieve a premium "tactical" feel, use **Glassmorphism** for all floating elements.
- **Glass Formula:** `surface-container-highest` at 40% opacity + `backdrop-filter: blur(12px)`.
- **Signature Glows:** Primary CTAs should not be flat. Apply a linear gradient from `primary` (#d7baff) to `primary_container` (#bd93f9) with a 5px outer glow of the same color at 20% opacity.

---

## 3. Typography: The Space Grotesk Standard
We use **Space Grotesk** exclusively. Its monospaced-influenced terminals provide the "tech" feel required for SOC environments while maintaining high legibility.

- **Display (The Pulse):** `display-lg` (3.5rem) / Medium weight. Used for critical threat counts.
- **Headline (The Directive):** `headline-md` (1.75rem) / Bold. For major section headers. Use `primary` (#d7baff) color to draw the eye.
- **Title (The Subject):** `title-md` (1.125rem) / Medium. For card titles and navigation.
- **Body (The Intelligence):** `body-md` (0.875rem) / Regular. For all descriptions. Use `on_surface_variant` (#ccc3d3) to reduce eye fatigue.
- **Labels (The Metadata):** `label-sm` (0.6875rem) / Bold / All Caps. For tags, timestamps, and status indicators.

---

## 4. Elevation & Depth

### The Layering Principle
Avoid drop shadows. Instead, use **Tonal Stacking**. An inner element must always be a lighter (higher) surface tier than its parent. 
*   *Example:* A list item (`surface-container-highest`) sitting inside a sidebar (`surface-container-low`).

### Ambient Shadows
If an element must float (e.g., a critical alert popover), use a **Tinted Ambient Shadow**:
- `box-shadow: 0 20px 40px rgba(189, 147, 249, 0.08);` (A subtle purple-tinted shadow that feels like light reflecting off a dark surface).

### Ghost Borders
Where accessibility requires a border, use the **Ghost Border**:
- `outline-variant` (#4a4451) at 15% opacity. It should be barely perceptible, serving more as a "hint" of a container than a hard wall.

---

## 5. Components

### Buttons (Tactical Triggers)
- **Primary:** Gradient fill (`primary` to `primary_container`). Text in `on_primary_fixed` (#290055). No border.
- **Secondary:** Ghost Border with `primary` text. On hover, apply a 5% `primary` background tint.
- **Tertiary:** `secondary` (#ffafd7) text, no background. Used for destructive or "Dismiss" actions.

### Chips (Data Tags)
- Use `tertiary_container` (#00c151) with `on_tertiary_fixed` (#002108) text for "Clean/Safe" status.
- Use `secondary_container` (#860f60) for "Threat/Critical" status.
- Shape: `Roundedness-full` (pill shape).

### Input Fields
- Background: `surface-container-lowest` (#0a0e19).
- Bottom-only Border: 2px of `outline-variant` (#4a4451). On focus, the border animates to `primary` (#d7baff) with a subtle 2px blur.

### Threat Cards & Lists
- **Forbid Dividers:** Never use lines to separate list items. Use a 0.4rem (`spacing-2`) gap and alternating `surface-container-low` and `surface-container-lowest` backgrounds.
- **The "Active Node" State:** When a card is selected, add a 2px vertical "power rail" on the left edge using `tertiary` (#31e368).

### Additional SOC Components
- **Pulse Indicator:** A small `tertiary` dot with a repeating scale-out animation to show "System Live."
- **Scanning Bar:** A thin `cyan` (#8be9fd) gradient line that moves vertically across a glass container to indicate an active scan.

---

## 6. Do's and Don'ts

### Do
- **Use High-Contrast Accents:** Use `Electric Pink` and `Glowing Green` for data visualization against the dark navy base.
- **Embrace Breathing Room:** Use the `spacing-16` (3.5rem) and `spacing-20` (4.5rem) for major layout margins to maintain a "premium" feel.
- **Layer Surfaces:** Always ensure nested containers move from darkest (bottom) to lightest (top).

### Don't
- **Don't use 100% white:** Use `on_surface` (#dfe2f2) for text. Pure white (#FFFFFF) is too jarring against the navy background and ruins the "premium" depth.
- **Don't use hard corners:** Stick strictly to the `md` (0.375rem) and `lg` (0.5rem) roundedness scale. Hard corners feel dated; soft corners feel engineered.
- **Don't clutter:** If the screen feels full, increase the spacing scale rather than adding lines. White space is a functional tool for cognitive load management in SOC platforms.